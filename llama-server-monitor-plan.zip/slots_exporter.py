#!/usr/bin/env python3
"""
slots_exporter.py — llama.cpp /slots + /metrics Prometheus sidecar

Polls llama-server's /slots endpoint every POLL_INTERVAL seconds and
re-exposes KV cache state and slot activity as Prometheus metrics.
Also re-exposes raw /metrics counters with richer labels.

Exposed metrics:
  llamacpp_slots_total          — total slot count configured
  llamacpp_slots_idle           — idle slots (ready for new request)
  llamacpp_slots_busy           — busy slots (actively inferring)
  llamacpp_slot_state{slot}     — per-slot state (0=idle, 1=busy)
  llamacpp_slot_kv_used{slot}   — tokens in KV cache for this slot
  llamacpp_slot_n_decoded{slot} — tokens decoded in current generation
  llamacpp_slot_prompt_len{slot}— prompt token count for current request

  llamacpp_decode_rate          — predicted tokens/s (from /metrics)
  llamacpp_prefill_rate         — prompt tokens/s (from /metrics)
  llamacpp_kv_cache_ratio       — KV cache usage ratio (from /metrics)
  llamacpp_kv_cache_tokens      — KV cache tokens used (from /metrics)
  llamacpp_requests_processing  — concurrent requests in flight
  llamacpp_rpc_overhead_estimate— estimated RPC gap: decode_rate vs expected
"""

import os
import time
import logging
import threading
import requests
from prometheus_client import (
    start_http_server, Gauge, Counter, REGISTRY, PROCESS_COLLECTOR,
    PLATFORM_COLLECTOR
)

# ── Config ────────────────────────────────────────────────────
LLAMA_HOST    = os.environ.get("LLAMA_HOST", "localhost")
LLAMA_PORT    = int(os.environ.get("LLAMA_PORT", "8081"))
POLL_INTERVAL = float(os.environ.get("POLL_INTERVAL", "2"))
EXPORTER_PORT = int(os.environ.get("EXPORTER_PORT", "9500"))

BASE_URL      = f"http://{LLAMA_HOST}:{LLAMA_PORT}"
SLOTS_URL     = f"{BASE_URL}/slots"
METRICS_URL   = f"{BASE_URL}/metrics"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# ── Prometheus metrics ────────────────────────────────────────
slots_total    = Gauge("llamacpp_slots_total",   "Total configured inference slots")
slots_idle     = Gauge("llamacpp_slots_idle",    "Idle slots (ready for requests)")
slots_busy     = Gauge("llamacpp_slots_busy",    "Busy slots (active inference)")

slot_state     = Gauge("llamacpp_slot_state",     "Slot state (0=idle 1=busy)",        ["slot"])
slot_kv_used   = Gauge("llamacpp_slot_kv_used",   "Tokens in KV cache for slot",       ["slot"])
slot_n_decoded = Gauge("llamacpp_slot_n_decoded", "Tokens decoded this generation",    ["slot"])
slot_prompt_len= Gauge("llamacpp_slot_prompt_len","Prompt token length for this slot", ["slot"])

decode_rate    = Gauge("llamacpp_decode_rate",         "Decode throughput tokens/s")
prefill_rate   = Gauge("llamacpp_prefill_rate",        "Prefill throughput tokens/s")
kv_ratio       = Gauge("llamacpp_kv_cache_ratio",      "KV cache usage ratio 0-1")
kv_tokens      = Gauge("llamacpp_kv_cache_tokens",     "Tokens in KV cache")
requests_proc  = Gauge("llamacpp_requests_processing", "In-flight inference requests")

scrape_errors  = Counter("llamacpp_exporter_scrape_errors_total",
                         "Number of failed scrapes", ["endpoint"])
last_scrape_ok = Gauge("llamacpp_exporter_last_scrape_success",
                        "1 if last scrape was successful, 0 if not")

# ── Parsers ───────────────────────────────────────────────────
def parse_prometheus_text(text: str) -> dict:
    """Parse llama-server /metrics Prometheus text into {metric_name: value}."""
    result = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 2:
            name = parts[0].split("{")[0]  # strip labels
            try:
                result[name] = float(parts[-1])
            except ValueError:
                pass
    return result

# ── Poll loop ─────────────────────────────────────────────────
def poll_slots():
    try:
        resp = requests.get(SLOTS_URL, timeout=3)
        resp.raise_for_status()
        slot_list = resp.json()
    except Exception as e:
        scrape_errors.labels(endpoint="slots").inc()
        log.warning(f"Failed to scrape /slots: {e}")
        last_scrape_ok.set(0)
        return

    n_idle = 0
    n_busy = 0
    for s in slot_list:
        sid   = str(s.get("id", 0))
        state = s.get("state", 0)       # 0=idle, 1=busy
        slot_state.labels(slot=sid).set(state)
        slot_kv_used.labels(slot=sid).set(s.get("n_ctx", 0) - s.get("n_ctx_remaining", s.get("n_ctx", 0)))
        slot_n_decoded.labels(slot=sid).set(s.get("n_decoded", 0))
        slot_prompt_len.labels(slot=sid).set(s.get("prompt_len", 0))
        if state == 0:
            n_idle += 1
        else:
            n_busy += 1

    slots_total.set(len(slot_list))
    slots_idle.set(n_idle)
    slots_busy.set(n_busy)


def poll_metrics():
    try:
        resp = requests.get(METRICS_URL, timeout=3)
        resp.raise_for_status()
        m = parse_prometheus_text(resp.text)
    except Exception as e:
        scrape_errors.labels(endpoint="metrics").inc()
        log.warning(f"Failed to scrape /metrics: {e}")
        last_scrape_ok.set(0)
        return

    decode_rate.set(m.get("llamacpp:predicted_tokens_seconds", 0))
    prefill_rate.set(m.get("llamacpp:prompt_tokens_seconds", 0))
    kv_ratio.set(m.get("llamacpp:kv_cache_usage_ratio", 0))
    kv_tokens.set(m.get("llamacpp:kv_cache_tokens", 0))
    requests_proc.set(m.get("llamacpp:requests_processing", 0))
    last_scrape_ok.set(1)


def poll_loop():
    log.info(f"Polling {BASE_URL} every {POLL_INTERVAL}s")
    while True:
        poll_slots()
        poll_metrics()
        time.sleep(POLL_INTERVAL)


# ── Main ──────────────────────────────────────────────────────
if __name__ == "__main__":
    # Remove default Python process/platform collectors (noise)
    try:
        REGISTRY.unregister(PROCESS_COLLECTOR)
        REGISTRY.unregister(PLATFORM_COLLECTOR)
    except Exception:
        pass

    start_http_server(EXPORTER_PORT)
    log.info(f"Slots exporter listening on :{EXPORTER_PORT}/metrics")

    # Run in main thread
    poll_loop()
