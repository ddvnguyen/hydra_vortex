#!/usr/bin/env bash
# ============================================================
# start-llama-server.sh
# Starts llama-server (main node) with RPC + full observability
#
# Usage:
#   chmod +x start-llama-server.sh
#   ./start-llama-server.sh
#
# Adjust MODEL, RPC_SERVER, TENSOR_SPLIT as needed.
# The --metrics and --slots flags are REQUIRED for Phase 3 observability.
# ============================================================

set -euo pipefail

# ── Config ───────────────────────────────────────────────────
MODEL="${MODEL:-/path/to/Qwen3.6-35B-A3B-APEX-I-Balanced.gguf}"
HOST="${LLAMA_HOST:-0.0.0.0}"
PORT="${LLAMA_PORT:-8081}"

# RPC server address for the P100 (adjust if different)
# Format: host:port  (default rpc-server port is 50052)
RPC_SERVER="${RPC_SERVERS:-127.0.0.1:50052}"

# Tensor split: proportion of layers per device
# Index 0 = main (RTX 5060 Ti), Index 1+ = RPC server (P100)
# Tune this — start 60/40, watch GPU utilization in Grafana
TENSOR_SPLIT="${TENSOR_SPLIT:-0.6,0.4}"

# Context size
CTX="${CTX_SIZE:-8192}"

# Number of parallel slots (concurrent requests)
PARALLEL="${PARALLEL:-2}"

# GPU layers to offload (-1 = all)
GPU_LAYERS="${GPU_LAYERS:--1}"

# ── Validate ─────────────────────────────────────────────────
if [ ! -f "$MODEL" ]; then
  echo "ERROR: Model file not found: $MODEL"
  echo "Set the MODEL environment variable:"
  echo "  MODEL=/path/to/your.gguf ./start-llama-server.sh"
  exit 1
fi

echo "============================================================"
echo " llama-server with RPC + Observability"
echo "============================================================"
echo " Model:         $MODEL"
echo " Host:Port:     $HOST:$PORT"
echo " RPC servers:   $RPC_SERVER"
echo " Tensor split:  $TENSOR_SPLIT"
echo " Context:       $CTX tokens"
echo " Parallel slots: $PARALLEL"
echo ""
echo " Metrics endpoint: http://$HOST:$PORT/metrics  (Prometheus)"
echo " Slots endpoint:   http://$HOST:$PORT/slots    (sidecar polls this)"
echo " Health endpoint:  http://$HOST:$PORT/health"
echo "============================================================"
echo ""
echo " Start the P100 RPC server first:"
echo "   llama-rpc-server --host 127.0.0.1 --port 50052"
echo ""

# ── Start ────────────────────────────────────────────────────
exec llama-server \
  --model "$MODEL" \
  --host "$HOST" \
  --port "$PORT" \
  \
  --rpc "$RPC_SERVER" \
  --tensor-split "$TENSOR_SPLIT" \
  \
  --ctx-size "$CTX" \
  --parallel "$PARALLEL" \
  --n-gpu-layers "$GPU_LAYERS" \
  \
  --metrics \
  --slots \
  \
  --cont-batching \
  --flash-attn \
  \
  --log-format text \
  2>&1 | tee /tmp/llama-server.log
